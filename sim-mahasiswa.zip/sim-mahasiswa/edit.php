<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($id === false || $id === null || $id < 1) {
    flash('error', t('not_found'));
    header('Location: index.php');
    exit;
}

// Ambil data lama berdasarkan identitas unik (id)
$stmt = $conn->prepare('SELECT nim, nama, email, jurusan, angkatan FROM mahasiswa WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$data) {
    flash('error', t('not_found'));
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid($_POST['csrf'] ?? null)) {
        $errors['form'] = t('invalid_request');
    } else {
        [$data, $errors] = validate_mahasiswa($_POST);

        if (empty($errors)) {
            try {
                // UPDATE
                $stmt = $conn->prepare('UPDATE mahasiswa SET nim = ?, nama = ?, email = ?, jurusan = ?, angkatan = ? WHERE id = ?');
                $stmt->bind_param('ssssii', $data['nim'], $data['nama'], $data['email'], $data['jurusan'], $data['angkatan'], $id);
                $stmt->execute();
                $stmt->close();
                flash('success', t('updated_ok'));
                header('Location: index.php');
                exit;
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $errors['nim'] = t('nim_exists');
                } else {
                    $errors['form'] = t('invalid_request');
                }
            }
        }
    }
}

$pageTitle = t('edit_student');
$backId = $id;
$submitLabel = t('update');
require __DIR__ . '/includes/header.php';
?>
<div class="card card-narrow">
  <h1><?= e(t('edit_student')) ?></h1>
  <?php if (!empty($errors['form'])): ?><div class="alert alert-error"><?= e($errors['form']) ?></div><?php endif; ?>
  <?php require __DIR__ . '/includes/form.php'; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
