<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

// READ: tampilkan semua data (dengan pencarian opsional)
$q = clean_text($_GET['q'] ?? '');
if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $conn->prepare('SELECT * FROM mahasiswa WHERE nim LIKE ? OR nama LIKE ? OR jurusan LIKE ? ORDER BY nim');
    $stmt->bind_param('sss', $like, $like, $like);
} else {
    $stmt = $conn->prepare('SELECT * FROM mahasiswa ORDER BY nim');
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$pageTitle = t('student_data');
$backId = null;
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="card-head">
    <h1><?= e(t('student_data')) ?></h1>
    <a href="create.php" class="btn btn-primary">+ <?= e(t('add_student')) ?></a>
  </div>

  <form method="GET" class="search" action="">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search_placeholder')) ?>">
    <button type="submit" class="btn"><?= e(t('search')) ?></button>
    <?php if ($q !== ''): ?><a href="index.php" class="btn"><?= e(t('reset')) ?></a><?php endif; ?>
  </form>

  <div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th><?= e(t('no')) ?></th><th><?= e(t('nim')) ?></th><th><?= e(t('name')) ?></th>
        <th><?= e(t('email')) ?></th><th><?= e(t('major')) ?></th><th><?= e(t('year')) ?></th>
        <th><?= e(t('action')) ?></th>
      </tr>
    </thead>
    <tbody>
    <?php if (count($rows) === 0): ?>
      <tr><td colspan="7" class="center"><?= e(t('empty')) ?></td></tr>
    <?php else: ?>
      <?php foreach ($rows as $i => $r): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= e($r['nim']) ?></td>
        <td><?= e($r['nama']) ?></td>
        <td><?= e($r['email']) ?></td>
        <td><?= e($r['jurusan']) ?></td>
        <td><?= e($r['angkatan']) ?></td>
        <td class="actions">
          <a href="edit.php?id=<?= (int)$r['id'] ?>" class="btn btn-small"><?= e(t('edit')) ?></a>
          <form method="POST" action="delete.php" onsubmit="return confirm('<?= e(addslashes(t('confirm_delete'))) ?>');">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button type="submit" class="btn btn-small btn-danger"><?= e(t('delete')) ?></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
  <p class="muted"><?= e(t('total', count($rows))) ?></p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
