<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean_text($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if (!csrf_valid($_POST['csrf'] ?? null)) {
        $error = t('invalid_request');
    } elseif ($username === '' || $password === '') {
        $error = t('login_required');
    } else {
        $stmt = $conn->prepare('SELECT id, username, password FROM users WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            $lang = $_SESSION['lang'];          // pertahankan bahasa pilihan
            session_regenerate_id(true);        // cegah session fixation
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['lang'] = $lang;
            header('Location: index.php');
            exit;
        }
        $error = t('login_failed');
    }
}

$pageTitle = t('login');
$backId = null;
require __DIR__ . '/includes/header.php';
?>
<div class="card card-narrow">
  <h1><?= e(t('login')) ?></h1>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <form method="POST" action="" novalidate>
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <div class="form-group">
      <label for="username"><?= e(t('username')) ?></label>
      <input type="text" id="username" name="username" value="<?= e($username) ?>" autofocus>
    </div>
    <div class="form-group">
      <label for="password"><?= e(t('password')) ?></label>
      <input type="password" id="password" name="password">
    </div>
    <button type="submit" class="btn btn-primary"><?= e(t('login')) ?></button>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
