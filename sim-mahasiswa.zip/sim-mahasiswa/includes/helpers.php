<?php
// Terjemahan: t('key') atau t('key', $arg1, ...)
function t(string $key, ...$args): string
{
    $text = $GLOBALS['LANG'][$key] ?? $key;
    return $args ? vsprintf($text, $args) : $text;
}

// Escape output untuk mencegah XSS
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Proteksi halaman: wajib login
function require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// CSRF token
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_valid(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

// Flash message (pesan sekali tampil)
function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function pull_flash(): ?array
{
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

// Sanitasi teks bebas: hapus tag HTML dan spasi berlebih
function clean_text($value): string
{
    return trim(strip_tags((string)$value));
}

/**
 * Validasi & sanitasi data mahasiswa.
 * Mengembalikan [data_bersih, daftar_error]
 */
function validate_mahasiswa(array $input): array
{
    $data = [];
    $errors = [];
    $fields = ['nim', 'nama', 'email', 'jurusan', 'angkatan'];

    foreach ($fields as $field) {
        $data[$field] = clean_text($input[$field] ?? '');
        $value = $data[$field];

        // Percabangan switch per field
        switch ($field) {
            case 'nim':
                if ($value === '') {
                    $errors['nim'] = t('err_required', t('nim'));
                } elseif (!preg_match('/^[0-9]{5,15}$/', $value)) {
                    $errors['nim'] = t('err_nim_format');
                }
                break;

            case 'nama':
                if ($value === '') {
                    $errors['nama'] = t('err_required', t('name'));
                } elseif (mb_strlen($value) > 100) {
                    $errors['nama'] = t('err_too_long', t('name'), 100);
                }
                break;

            case 'email':
                $email = filter_var($value, FILTER_SANITIZE_EMAIL);
                if ($value === '') {
                    $errors['email'] = t('err_required', t('email'));
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors['email'] = t('err_email_format');
                } else {
                    $data['email'] = $email;
                }
                break;

            case 'jurusan':
                if ($value === '') {
                    $errors['jurusan'] = t('err_required', t('major'));
                } elseif (mb_strlen($value) > 100) {
                    $errors['jurusan'] = t('err_too_long', t('major'), 100);
                }
                break;

            case 'angkatan':
                $year = filter_var($value, FILTER_VALIDATE_INT, [
                    'options' => ['min_range' => 2000, 'max_range' => (int)date('Y')]
                ]);
                if ($value === '') {
                    $errors['angkatan'] = t('err_required', t('year'));
                } elseif ($year === false) {
                    $errors['angkatan'] = t('err_year_range', (int)date('Y'));
                } else {
                    $data['angkatan'] = $year;
                }
                break;
        }
    }
    return [$data, $errors];
}
