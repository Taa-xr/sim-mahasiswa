<?php
// Variabel opsional: $pageTitle, $backId (id untuk kembali ke halaman edit)
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$langQuery = function (string $lang) use ($currentPage, $backId) {
    $q = ['lang' => $lang, 'back' => $currentPage];
    if (!empty($backId)) $q['id'] = (int)$backId;
    return 'set_lang.php?' . http_build_query($q);
};
$flash = pull_flash();
?>
<!DOCTYPE html>
<html lang="<?= e($_SESSION['lang']) ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? t('app_title')) ?> - <?= e(t('app_title')) ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <div class="brand"><?= e(t('app_title')) ?></div>
  <nav>
    <span class="lang">
      <?= e(t('language')) ?>:
      <a href="<?= e($langQuery('id')) ?>" class="<?= $_SESSION['lang']==='id' ? 'active' : '' ?>">ID</a> |
      <a href="<?= e($langQuery('en')) ?>" class="<?= $_SESSION['lang']==='en' ? 'active' : '' ?>">EN</a>
    </span>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <span><?= e(t('hello', $_SESSION['username'])) ?></span>
      <a class="btn btn-small" href="logout.php"><?= e(t('logout')) ?></a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
<?php if ($flash): ?>
  <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
