<?php
// Partial form (dipakai create.php & edit.php)
// Variabel: $data, $errors, $submitLabel
$field = function (string $name, string $label, string $type = 'text') use ($data, $errors) {
    $err = $errors[$name] ?? '';
    echo '<div class="form-group">';
    echo '<label for="' . e($name) . '">' . e($label) . '</label>';
    echo '<input type="' . e($type) . '" id="' . e($name) . '" name="' . e($name) . '" value="' . e($data[$name] ?? '') . '" class="' . ($err ? 'invalid' : '') . '">';
    if ($err) echo '<small class="error">' . e($err) . '</small>';
    echo '</div>';
};
?>
<form method="POST" action="" novalidate>
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <?php
    $field('nim', t('nim'));
    $field('nama', t('name'));
    $field('email', t('email'), 'email');
    $field('jurusan', t('major'));
    $field('angkatan', t('year'), 'number');
  ?>
  <div class="form-actions">
    <button type="submit" class="btn btn-primary"><?= e($submitLabel) ?></button>
    <a href="index.php" class="btn"><?= e(t('cancel')) ?></a>
  </div>
</form>
