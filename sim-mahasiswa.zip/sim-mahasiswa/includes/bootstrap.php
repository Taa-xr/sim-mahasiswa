<?php
// Dimuat di setiap halaman: session, koneksi DB, bahasa, helper
session_start();

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/helpers.php';

const SUPPORTED_LANGS = ['id', 'en'];

// Bahasa disimpan di $_SESSION agar konsisten antarhalaman
if (empty($_SESSION['lang']) || !in_array($_SESSION['lang'], SUPPORTED_LANGS, true)) {
    $_SESSION['lang'] = 'id';
}
$GLOBALS['LANG'] = require __DIR__ . '/../lang/' . $_SESSION['lang'] . '.php';
