<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

// DELETE hanya lewat POST + token CSRF
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid($_POST['csrf'] ?? null)) {
    flash('error', t('invalid_request'));
    header('Location: index.php');
    exit;
}

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
if ($id === false || $id === null || $id < 1) {
    flash('error', t('not_found'));
} else {
    $stmt = $conn->prepare('DELETE FROM mahasiswa WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $deleted = $stmt->affected_rows;
    $stmt->close();
    flash($deleted > 0 ? 'success' : 'error', $deleted > 0 ? t('deleted_ok') : t('not_found'));
}
header('Location: index.php');
exit;
