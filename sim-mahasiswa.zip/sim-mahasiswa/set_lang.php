<?php
require_once __DIR__ . '/includes/bootstrap.php';

$lang = $_GET['lang'] ?? 'id';
if (in_array($lang, SUPPORTED_LANGS, true)) {
    $_SESSION['lang'] = $lang;   // simpan pilihan bahasa di session
}

// Redirect aman: hanya halaman yang diizinkan (whitelist)
$allowed = ['index.php', 'create.php', 'edit.php', 'login.php'];
$back = $_GET['back'] ?? 'index.php';
if (!in_array($back, $allowed, true)) {
    $back = 'index.php';
}
$url = $back;
if ($back === 'edit.php' && isset($_GET['id'])) {
    $url .= '?id=' . (int)$_GET['id'];
}
header('Location: ' . $url);
exit;
