<?php
session_start();
$lang = $_SESSION['lang'] ?? 'id';
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

// Mulai session baru agar pilihan bahasa tetap terbawa ke halaman login
session_start();
$_SESSION['lang'] = in_array($lang, ['id', 'en'], true) ? $lang : 'id';
header('Location: login.php');
exit;
