<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$data = ['nim' => '', 'nama' => '', 'email' => '', 'jurusan' => '', 'angkatan' => ''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid($_POST['csrf'] ?? null)) {
        $errors['form'] = t('invalid_request');
    } else {
        [$data, $errors] = validate_mahasiswa($_POST);

        if (empty($errors)) {
            try {
                // CREATE
                $stmt = $conn->prepare('INSERT INTO mahasiswa (nim, nama, email, jurusan, angkatan) VALUES (?, ?, ?, ?, ?)');
                $stmt->bind_param('ssssi', $data['nim'], $data['nama'], $data['email'], $data['jurusan'], $data['angkatan']);
                $stmt->execute();
                $stmt->close();
                flash('success', t('created_ok'));
                header('Location: index.php');
                exit;
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $errors['nim'] = t('nim_exists');
                } else {
                    $errors['form'] = t('invalid_request');
                }
            }
        }
    }
}

$pageTitle = t('add_student');
$backId = null;
$submitLabel = t('save');
require __DIR__ . '/includes/header.php';
?>
<div class="card card-narrow">
  <h1><?= e(t('add_student')) ?></h1>
  <?php if (!empty($errors['form'])): ?><div class="alert alert-error"><?= e($errors['form']) ?></div><?php endif; ?>
  <?php require __DIR__ . '/includes/form.php'; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
