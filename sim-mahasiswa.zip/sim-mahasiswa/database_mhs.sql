-- Skrip database SIM Mahasiswa
CREATE DATABASE IF NOT EXISTS sim_mahasiswa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sim_mahasiswa;

DROP TABLE IF EXISTS mahasiswa;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE mahasiswa (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nim VARCHAR(15) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  jurusan VARCHAR(100) NOT NULL,
  angkatan SMALLINT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Akun default: admin / admin123 (hash bcrypt dari password_hash())
INSERT INTO users (username, password) VALUES ('admin', '$2b$12$ufgRZfkGxanL/wNvmA2tpuiSkSmxQUJN1MkLINwQvFavH8q5VzPZ6');

INSERT INTO mahasiswa (nim, nama, email, jurusan, angkatan) VALUES
('2301001', 'Siti Aisyah', 'siti@email.com', 'Teknik Informatika', 2023),
('2301002', 'Budi Santoso', 'budi@email.com', 'Sistem Informasi', 2023),
('2201003', 'Rina Marlina', 'rina@emailxample.com', 'Teknik Informatika', 2022);
